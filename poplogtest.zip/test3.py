import win32api, win32con, time, re
from selenium import webdriver

# 加载谷歌驱动器
wd = webdriver.Chrome(r'D:\PycharmProjects\chromedriver.exe')
# 目标url
url = 'https://jira.pg.com.cn/secure/Dashboard.jspa?selectPageId=11610'
# 已登录的cookie信息
cookie = dict(name='JSESSIONID',value='59230BA4825881D4D0CFCA2A97B02070')
# 开始访问目标网站
wd.get(url)
wd.add_cookie(cookie)
wd.get(url)

while True:

    # 获取列表实体的内容
    el2 = wd.find_element_by_xpath('//div[@id="gadget-12503"]').text
    # 获取
    # 查找时间不足的单子
    # 存储是否需要警报
    erros = 0
    # 存储错误信息
    warn = ''
    if el2 != 'No matching issues found.':
        print("erros")
    else:
        print("ok")
    break
    # if erros == 1:
    #     # 系统弹出框，提示
    #     win32api.MessageBoxEx(0, warn, "有单子快到期啦", win32con.MB_OK)

    # 当前程序中断半小时
    # time.sleep(360)