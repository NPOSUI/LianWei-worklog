import win32api, win32con, time, re
from selenium import webdriver

# 驱动器路径,最好纯英文路径
dri = "D:\PycharmProjects\chromedriver.exe"
# 加载谷歌驱动器，如是其他浏览器需更换驱动
wd = webdriver.Chrome(dri)

# 目标url
url = 'https://jira.pg.com.cn/secure/Dashboard.jspa?selectPageId=11610'
# 已登录的cookie信息，免登录
cookie = dict(name='JSESSIONID',value='59230BA4825881D4D0CFCA2A97B02070')

# 开始访问目标网站
wd.get(url)
wd.add_cookie(cookie)
wd.get(url)

while True:
    # 刷新页面
    wd.refresh()
    # 隐式等待
    wd.implicitly_wait(5)
    # 获取第一处需要监控的列表的内容
    el1 = wd.find_element_by_xpath('//div[@id="gadget-12322"]//table[@class="issue-table"]/tbody').text
    # 获取第二处需监控的内容
    el2 = wd.find_element_by_xpath('//div[@id="gadget-12503"]').text

    # 查找时间不足的单子
    # \n分段成单子list
    e = el1.split('\n')
    # 存储是否需要警报
    erros = 0
    # 存储错误信息
    warn = ''
    # 获取单子list长度
    maxle = len(e)

    # 获取第一监控处是否有单子出现
    # 步长为三，获取每个单子的时间段
    for i in range(0, maxle, 3):
        dt = e[i]
        print(dt)
        # 判断时常是不是超过一小时
        m = re.findall("[d,h]", dt)
        if m:
            print("ok")
        else:
            # 获取小于一小时的时间
            r1 = re.findall("(\d*)m", dt)
            r2 = r1[0]
            r = int(r2)
            # 判断是否小等于30分钟
            if r <= 30:
                # 加入错误信息
                wa = ','.join([e[i], e[i+1], e[i+2]])
                warn += wa
                warn += '\n'
                erros = 1

    # 判断第二监控处是否有单子出现
    if el2 != "No matching issues found.":
        erros = 1
        # 加入错误信息
        warn += el2
        warn += '\n'

    # 判断是否需要提醒
    if erros == 1:
        # 系统弹出框，提示
        win32api.MessageBoxEx(0, warn, "有单子快到期啦", win32con.MB_OK)

    # 程序中断半小时
    time.sleep(360)



