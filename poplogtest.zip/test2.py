import re

el = '4h 27m\nSu zhipeng PSD-23869\n微信消息告警设置\n1h 50m\nSu zhipeng PSD-23852\n申请修复qa、prod环境的ingress索引中字段类型问题\n7h 25m\nNoah Lu PSD-23782\nGolden PIPE(CDLMDM) 发版,需要PAAS stand by支持on 20201212'
e = el.split('\n')
# 存储是否需要警报
erros = 0
# 获取单子list长度
maxle = len(e)
#
# 步长为三，获取每个单子的时间段
for i in range(0, maxle, 3):
    dt = e[i]
    # 判断时常是不是超过一小时
    m = re.findall("[d]", dt)
    if m:
        print("ok")
    else:
        # 获取小于一小时的时间
        r = re.findall("(\d+)m", dt)
        r = ''.join(r)
        r = int(r)
        # 判断是否小于30m
        if r <= 50:
            # 加入错误信息

            wa = ','.join([e[i], e[i + 1], e[i + 2]])
            warn += wa
            warn += '\n'
            erros = 1

print(warn)